package even

/*
  这是第一个包，主要计算传入的值是否被2整除
  主要是测试用，你可以使用
 */
func Even(i int) bool {
	return i%2 == 0
}

func odd(i int) bool  {
	return i%2 == 0
}
