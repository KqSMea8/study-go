package main

import(
	"time"
	"fmt"
)

func main() {
	fmt.Println(time.Now().Unix())
}
