package common

//import "fmt"

func isError(sobj error) {

}
